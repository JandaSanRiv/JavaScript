"use strict" // obliga a que no se puedan usar vaiables si no se definen
var numero1 = 1000;
var nombre = "Alma";
