// definir un arreglo vacio
let arreglo = [];
function addItemToArray()
{
    let dato = window.prompt("Ingresa un elemnto");
    let listaElem = document.getElementById("listaElementos");
    let newElem = null;
    if(dato !=null){
        arreglo.push(dato);
        // newElem =document.createElement("li");
        // newElem.innerText = dato;
        // listaElem.appendChild(newElem);
        agregarElemento(listaElem, dato);

    }
    // listaElem.removeChild(listaElem.firstChild);
    console.log(arreglo);
    console.log("Tu arreglo actual es: \n " + arreglo);
    console.log("---------------------------------------");
    var i = 0;
    arreglo.forEach(element => {
        console.log((i++)+". "+element)
    });
    console.log("---------------------------------------");
}

function agregarElemento(id, text){
    let nvoElemento = document.createElement("li");
    nvoElemento.innerText = text;
    id.appendChild(nvoElemento);
}
function cleanList(){
    limpiarLista('listaElementos');
}

function limpiarLista(idList){
    let listaElem = document.getElementById(idList);
    if(listaElem !=null && listaElem != undefined)
        while(listaElem.firstChild)
        {
        listaElem.removeChild(listaElem.firstChild)
        }
}

function removeLastChild(){
    elimUltimoHijo( document.getElementById("listaElementos"))
}

function elimUltimoHijo(id)
{
    if(id !=null && id.hasChildNodes())
    id.removeChild(id.lastChild);
}


function removeFirstChild(){
    elimPrimerHijo( document.getElementById("listaElementos"))
}

function elimPrimerHijo(id)
{
    if(id !=null && id.hasChildNodes())
        id.removeChild(id.firstChild)
}